@echo off
title TM-FAILURE ANALYSIS AND SURVEILLANCE TOOL
cd /d "%~dp0"
echo ======================================================================
echo  🚆 TM-FAILURE ANALYSIS AND SURVEILLANCE TOOL - SWR TRACK MACHINES
echo  Theme: Pista Green & Golden on Dim Unimat Repair Atmosphere
echo ======================================================================
echo Launching Dashboard at http://localhost:8088/index.html ...

start "" "http://localhost:8088/index.html"
powershell -ExecutionPolicy Bypass -File "%~dp0server.ps1"
pause
